<?php

namespace pocketmine\inventory;

use pocketmine\inventory\InventoryType;
use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\network\mcpe\protocol\BlockEventPacket;
use pocketmine\Player;
use pocketmine\Server;
use pocketmine\tile\Dropper;

class DropperInventory extends ContainerInventory {
	
	public function __construct(Dropper $tile) {
		parent::__construct($tile, InventoryType::get(InventoryType::DROPPER));
	}

	/**
	 * @return Dropper
	 */
	public function getHolder() {
		return $this->holder;
	}

	public function onOpen(Player $who) {
		parent::onOpen($who);
		if (count($this->getViewers()) === 1) {
			$pk = new BlockEventPacket();
			$pk->x = $this->holder->getX();
			$pk->y = $this->holder->getY();
			$pk->z = $this->holder->getZ();
			$pk->case1 = 1;
			$pk->case2 = 2;
			if (($level = $this->holder->getLevel()) instanceof Level) {
				
				Server::getInstance()->broadcastPacket($level->getPlayers(), $pk);
			}
		}
	}

	public function onClose(Player $who) {
		if (count($this->getViewers()) === 1) {
			$pk = new BlockEventPacket();
			$pk->x = $this->holder->getX();
			$pk->y = $this->holder->getY();
			$pk->z = $this->holder->getZ();
			$pk->case1 = 1;
			$pk->case2 = 0;
			if (($level = $this->holder->getLevel()) instanceof Level) {
				Server::getInstance()->broadcastPacket($level->getPlayers(), $pk);
			}
		}
		parent::onClose($who);
	}
	
	/**
	 * 
	 * @return Item | null
	 */
	public function getFirstItem(&$itemIndex) {
		foreach($this->getContents() as $index => $item){
			if ($item->getId() != Item::AIR && $item->getCount() >= 0) {
				$itemIndex = $index;
				return $item;
			}
		}
		return null;
	}
	
}