<?php


namespace pocketmine\inventory;


use pocketmine\entity\Human;
use pocketmine\tile\EnderChest;

class EnderChestInventory extends ChestInventory
{
    /** @var FakeBlockMenu */
    protected $holder;

    public function __construct(Human $owner)
    {
        ContainerInventory::__construct(new FakeBlockMenu($this, $owner->getPosition()), InventoryType::get(InventoryType::CHEST));
    }

    public function getName(): string
    {
        return "EnderChest";
    }

    /**
     * Set the holder's position to that of a tile
     *
     * @param EnderChest $enderChest
     */
    public function setHolderPosition(EnderChest $enderChest)
    {
        $this->holder->setComponents($enderChest->getX(), $enderChest->getY(), $enderChest->getZ());
        $this->holder->setLevel($enderChest->getLevel());
    }

    /**
     * This override is here for documentation and code completion purposes only.
     * @return FakeBlockMenu
     */
    public function getHolder()
    {
        return $this->holder;
    }
}