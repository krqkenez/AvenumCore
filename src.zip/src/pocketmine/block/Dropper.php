<?php

namespace pocketmine\block;

use pocketmine\block\Block;
use pocketmine\item\Item;
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\FloatTag;
use pocketmine\nbt\tag\IntTag;
use pocketmine\nbt\tag\ShortTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\tile\Dropper as DropperTile;
use pocketmine\tile\Tile;

class Dropper extends Solid {
	
	protected $id = self::DROPPER;

	public function __construct($meta = 0){
		$this->meta = $meta;
	}
	
	public function getName(){
		return "Dropper";
	}
	
	public function place(Item $item, Block $block, Block $target, $face, $fx, $fy, $fz, Player $player = null) {
		if ($player->pitch > 45) {
			$this->meta = 1;
		} else if ($player->pitch < -45) {
			$this->meta = 0;
		} else {
			if ($player->yaw <= 45 || $player->yaw > 315) {
				$this->meta = 2;
			} else if ($player->yaw > 45 && $player->yaw <= 135) {
				$this->meta = 5;
			} else if ($player->yaw > 135 && $player->yaw <= 225) {
				$this->meta = 3;
			} else {
				$this->meta = 4;
			}
		}
		$this->getLevel()->setBlock($this, $this, true, true);
		return true;
	}
	
	public function getDropSide() {
		$face = $this->getFace();
		switch ($face) {
			case 0:
				return self::SIDE_DOWN;
			case 1:
				return self::SIDE_UP;
			case 2:
				return self::SIDE_SOUTH;
			case 3:
				return self::SIDE_NORTH;
			case 4:
				return self::SIDE_EAST;
			case 5:
				return self::SIDE_WEST;
		}
		return null;
	}
	
	private function isWasActivated() {
		return $this->meta >> 3;
	}
	
	private function activate() {
		$this->meta |= 0x08;
		$this->level->setBlock($this, $this, false, false);
		//$this->shoot();
	}
	
	private function deactivate() {
		$this->meta &= 0x07;
		$this->level->setBlock($this, $this, false, false);
	}
	
	public function canBeActivated() {
		return true;
	}
	
	public function onActivate(Item $item, Player $player = null) {
		$tile = $this->level->getTile($this);
		if (!($tile instanceof DropperTile)) {
			$nbt = new CompoundTag("", [
				new ListTag("Items", []),
				new StringTag("id", Tile::DROPPER),
				new IntTag("x", $this->x),
				new IntTag("y", $this->y),
				new IntTag("z", $this->z)
			]);
			$nbt->Items->setTagType(NBT::TAG_Compound);
			$tile = Tile::createTile(Tile::DROPPER, $this->level, $nbt);
		}
		$player->addWindow($tile->getInventory());
		return true;
	}
	
	public function getFace() {
		return $this->meta & 0x07;
	}
	
	protected function shoot() {
		$tile = $this->level->getTile($this);
		if ($tile instanceof DropperTile) {
			$dropperInventory = $tile->getInventory();
			$item = $dropperInventory->getFirstItem($index);
			if ($item != null) {
				// decreasing item logic
				if ($item->count == 1) { // we shoot last item in slot
					$dropperInventory->clear($index);
				} else {
					$item->count--;
					$dropperInventory->setItem($index, $item);
				}
				// drop item
				$params = $this->calculateShootingParams();
				$nbt = new CompoundTag("", [
					"Pos" => new Enum("Pos", [new DoubleTag("", $params['x']), new DoubleTag("", $params['y']), new DoubleTag("", $params['z'])]),
					"Rotation" => new Enum("Rotation", [
						new FloatTag("", $params['yawRad'] * 180 / M_PI),
						new FloatTag("", $params['pitchRad'] * 180 / M_PI)
					]),
					"Motion" => new Enum("Motion", [
						new DoubleTag("", -sin($params['yawRad']) * cos($params['pitchRad']) / 10),
						new DoubleTag("", 0),
						new DoubleTag("", cos($params['yawRad']) * cos($params['pitchRad']) / 10)
					]),
					"Health" => new ShortTag("Health", 5),
					"Item" => NBT::putItemHelper(Item::get($item->getId(), $item->getDamage())),
					"PickupDelay" => new ShortTag("PickupDelay", 20)
				]);
				$projectile = Entity::createEntity("Item", $this->level->getChunk($this->x >> 4, $this->z >> 4), $nbt);
				$projectile->spawnToAll();
			}
		}
	}
	
	
	protected function calculateShootingParams() {
		$data = [
			'x' => $this->x,
			'y' => $this->y,
			'z' => $this->z,
			'yawRad' => 0,
			'pitchRad' => 0,
		];
		$face = $this->getFace();
		if ($face == self::FACE_DOWN) {
			$data['pitchRad'] = 0.5 * M_PI;
		} else if ($face == self::FACE_UP) {
			$data['pitchRad'] = -0.5 * M_PI;
		} else {
			$data['y'] += 0.5;
			if ($face == self::FACE_SOUTH) {
				$data['x'] += 0.5;
				$data['z'] += 2;
			} else if ($face == self::FACE_NORTH) {
				$data['yawRad'] = M_PI;
				$data['x'] += 0.5;
				$data['z'] -= 1;
			} else if ($face == self::FACE_WEST) {
				$data['yawRad'] = 0.5 * M_PI;
				$data['x'] -= 1;
				$data['z'] += 0.5;
			} else if ($face == self::FACE_EAST) {
				$data['yawRad'] = 1.5 * M_PI;
				$data['x'] += 2;
				$data['z'] += 0.5;
			}
		}
		return $data;
	}

}