<?php

/*
 * Namespace: AvenumCore 1.0 - beta release
 * Данное ядро находится в открытом доступе, разрешается использовать на своих серверах.
 * Все права данного ядра принадлежат - krqkenez (Михаил Хрущев)
 * Перед сливом обязательно указывать автора: Группа ВК - @avenumstudios
 * Данное ядро является форком Prismarine с работающим Rcon и другими пофикшенными фишками.
 * API: 3.0.0 (PMMP3)
 * Версия bin: 7.2, 7.3 (VDS/VPS - 7.2)
 * @author - https://github.com/krqkenez
 * @vkgroup - https://vk.com/avenumstudios
 * @telegram - https://t.me/rqketa
 * start.sh вместе с этим ядром я положил в комплекте.
 *
 * 
 * 
 *
 *
*/

declare(strict_types=1);

namespace pocketmine;

use pocketmine\permission\ServerOperator;

interface IPlayer extends ServerOperator{

	/**
	 * @return bool
	 */
	public function isOnline() : bool;

	/**
	 * @return string
	 */
	public function getName();

	/**
	 * @return bool
	 */
	public function isBanned() : bool;

	/**
	 * @param bool $banned
	 */
	public function setBanned(bool $banned);

	/**
	 * @return bool
	 */
	public function isWhitelisted() : bool;

	/**
	 * @param bool $value
	 */
	public function setWhitelisted(bool $value);

	/**
	 * @return Player|null
	 */
	public function getPlayer();

	/**
	 * @return int|double
	 */
	public function getFirstPlayed();

	/**
	 * @return int|double
	 */
	public function getLastPlayed();

	/**
	 * @return bool
	 */
	public function hasPlayedBefore() : bool;

}
