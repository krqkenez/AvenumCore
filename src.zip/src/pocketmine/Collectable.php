<?php

/*
 * Namespace: AvenumCore 1.0 - beta release
 * Данное ядро находится в открытом доступе, разрешается использовать на своих серверах.
 * Все права данного ядра принадлежат - krqkenez (Михаил Хрущев)
 * Перед сливом обязательно указывать автора: Группа ВК - @avenumstudios
 * Данное ядро является форком Prismarine с работающим Rcon и другими пофикшенными фишками.
 * API: 3.0.0 (PMMP3)
 * Версия bin: 7.2, 7.3 (VDS/VPS - 7.2)
 * @author - https://github.com/krqkenez
 * @vkgroup - https://vk.com/avenumstudios
 * @telegram - https://t.me/rqketa
 * start.sh вместе с этим ядром я положил в комплекте.
 *
 * 
 * 
 *
 *
*/

declare(strict_types=1);

namespace pocketmine;

abstract class Collectable extends \Threaded implements \Collectable{

	private $isGarbage = false;

	public function isGarbage() : bool{
		return $this->isGarbage;
	}

	public function setGarbage(){
		$this->isGarbage = true;
	}
}
